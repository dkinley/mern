import React, { useState } from 'react';

const Pass = (props) => {
    const [ password, setPassword ] = useState("Your Password");
    const [ confirmPassword, setConfirmPassword] = useState("Confirming your Password");

    const formDataDivStyle = {
        textAlign: "left", 
        width: "350px", 
        margin: "auto",
        }
    
    const inputDataDivStyle = {
        borderRadius: "8px",
        backgroundColor: "sky",
        border: "1px solid darkgrey",
        padding: "2px 10px",
        margin: "6px",
        }

            return (
        <div>
        <form style={{ marginTop: "20px" }}>
            <div style={inputDataDivStyle}>
            <label htmlFor="password">Password</label>
            <input 
                type="password" 
                name="password" 
                onChange={ (e) => setPassword(e.target.value) }
            />
            </div>
            <div style={inputDataDivStyle}>
            <label htmlFor="confirmPassord">Confirm Password</label>
            <input 
                type="password" 
                name="confirmPassword" 
                onChange={ (e) => setConfirmPassword(e.target.value) }
            />
            </div>
        </form>


        <div style={ formDataDivStyle }>
                <h3 style={{ textAlign: 'center' }}>Your Password Info</h3>
                <p>
                <label>Password: </label>{ password }
                </p>
                <p>
                <label>Confirm Password: </label>{ confirmPassword }
                </p>
            </div>
        </div>
    )
}

    export default Pass;