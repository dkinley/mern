import React, {useState} from 'react';
import './App.css';

function App() {
  // This is the creating and naming new tasks. With square brackets to the right of = sign this is saying the the left is an array
  const [title, setTitle] = useState("");
  // This is the holding of tasks in a task list, aka array. Fyi, if you default the ([]) to null ([""]) or null it will break map funct
  const [items, setItems] = useState([]);

  // This is the form handling submit "add" from button below
  const handleItemSubmit = (event) => {
    event.preventDefault();  // this is the function to stop default page refresh by browser

    const newItem = {
      title: title,
      complete: false,
    };
  
    setItems([newItem,...items])

  };
  // The below is function to handle the delete button
  // The filter method is the easiest way to remove items from a list
  // Takes in the item to be deleted
  const handleItemDelete = (itemToDel) => {
    const filteredItems = items.filter((item) => {
      return itemToDel !== item;
    });

    setItems(filteredItems);
  };

  //The below handles items that have the checkbox checked
  const handleItemChecked = (event, itemToUpdate) => {
    const updatedItems = items.map((item) => {
        if (item === itemToUpdate) {
          const copiedItem = {...item };
          copiedItem.complete = event.target.checked;
          return copiedItem;
        }
        return item;
    })
    setItems(updatedItems);
  };

  return (
    <div className="App">
      <form 
        onSubmit={(event) => {
          handleItemSubmit(event);
        }}
      >
        <div>  {/* this div is used as a form input group, which in this case is a name and input box  */}
        <label>Task: </label>
          {/* below we keep track on input boxes changing value, use onChange.  
          We are passing in a callback function which is passed an event (e), where the target of
          the event is html element that is triggering the onChange. The input box requires a '.value'.
          By doing the below we are keeping track of the title by using the setTitle. Title's new value is 
          passed via the .value to the 'title' variable above, which is using state */}
        <input 
          onChange={ (e) => { 
            setTitle(e.target.value);
          }} 
          type="text"
          />
          </div>

          <button>Add</button>
          {/* This button is added after adding the form above. It is added to allow adding  */}
        </form>
          
          {/* This is the strikethrough text formatting when a checkbox has been checked */}
          {items.map ((item, i) => {
            const titleStyles = {};
          if (item.complete){
            titleStyles.textDecoration = "line-through";
          }

            return (
              <div key={i}>
                <span style={titleStyles}>{item.title}</span>
                <input onChange={(event) => {
                  handleItemChecked(event, item);
                }} 
                type= "checkbox" />
                <button onClick={(event) => {
                  handleItemDelete(item);
                }}>Delete</button>
            </div>
            );
          })}
        
    </div>
  );
}

export default App;
