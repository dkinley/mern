import React, {useState, useEffect} from 'react';
import axios from 'axios';

const FilmDetails = (props) => {
    const [ film, setFilm ] = useState({});
    
    useEffect(() => {
        axios.get("https://swapi.dev/api/films/" + props.episode_id + "/")
            .then((response) => {
                console.log("I am now over here!")
                console.log(response);
                setFilm(response.data);
            })
            .catch((error) => {
                console.log(error);
            })
        }, []);

        return (
            <div>
                <p>Title : { film.title }</p>
                <p>Episode : { film.episode_id }</p>
                <p>Release Date : { film.release_date }</p>
                <p>Director : { film.director }</p>
                <p>Producer : { film.producer }</p>
                <p>Opening : { film.opening_crawl }</p>
                <p>Characters : { film.characters }</p>
            </div>
        )
}

export default FilmDetails;