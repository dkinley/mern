import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link } from '@reach/router';

const Films = (props) => {
    const [ films, setFilms ] = useState([]);

    useEffect(() => {

        axios.get("https://swapi.dev/api/films")
            .then((response) => {
                console.log(response);
                setFilms(response.data.results);
            })
            .catch((error) => {
                console.log(error);
            });
    }, []);

    const getEpisodeIDFromURL = (url) => {
        const urlParts = url.split("/");
        console.log(urlParts);
        return urlParts[ urlParts.length -2 ];
    }

    return (
        <div>
        List of Star Wars Films
            {
                films.map((film, index) => (
                <div key={index} >
                
                    <Link to={ "/films/" + getEpisodeIDFromURL(film.url) }>
                    <h4>{film.title}</h4>
                    </Link>
                    <p>First Year in Theatres: {film.release_date}</p>
                    <br />

                </div>
                ))
            }
        </div>
    )
}

export default Films;