import axios from 'axios';
import React, {useState, useEffect} from 'react';
import Person from "./Person"

const Search = (props) =>  {

    const [search, setSearch] = useState({});

    useEffect(() => {

        axios.get('https://swapi.dev/api/' + props.personID)
            .then((res) => {
                setSearch(res.data);
            })

    }, []);

    return (
    <div>
        <h3>Search Bar</h3>
        <div class="dropdown">
        <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            Dropdown
        </button>
            <div class="dropdown-menu" aria-labelledby="dropdownMenu2">
                <button class="dropdown-item" type="button">People</button>
                <button class="dropdown-item" type="button">Planets</button>
                <button class="dropdown-item" type="button">Films</button>
            </div>
        </div>
            <div class="input-group mb-3">
                <input type="text" class="form-control" placeholder="Plant, Person or Other #" aria-label="Recipient's username" aria-describedby="button-addon2"/>
                <div class="input-group-append">
                <button class="btn btn-outline-secondary" type="button" id="button-addon2">Button</button>
                </div>
            </div>
        </div>
    )
}
export default Search;