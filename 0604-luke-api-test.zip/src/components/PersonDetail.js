import axios from 'axios';
import React, {useState, useEffect} from 'react';


const PersonDetails = (props) => {

    const [person, personID] = useState({});

    useEffect(() => {

        axios.get('https://swapi.dev/api/people' + props.personID)
            .then((res) => {
                setPerson(res.data);
            })

        }, []);

    return (
        <div>
            <h1>{ person.name }</h1>
            <p><strong>Gender : </strong> {person.gender}</p>
            <p><strong>Height : </strong> {person.height}</p>
            <p><strong>Mass : </strong> {person.mass}</p>
            <p><strong>Hair Color : </strong> {person.hair_color}</p>
        </div>
    )
}
export default PersonDetails;