import axios from 'axios';
import React, {useState, useEffect} from 'react';

const Person = () => {

    const [ PersonArray, setPersonArray ] = useState([]);
    const [ PersonUrl, setPersonUrl ] = useState('https://swapi.dev/api/people/');

    function getPersonID(url) {
        const splitItems = url.split("/");
        return splitItems[ splitItems.length -2];
    }

        useEffect(() => {
        
        axios.get(personUrl)
            .then((res) => {
            console.log(res.data, "from axios");
            setPersonArray(res.data.results);
            })

        }, [personUrl]);

        return (
            <PersonDetail />
        )
}
export default Person;