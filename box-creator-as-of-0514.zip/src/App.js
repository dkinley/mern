import React, { useState } from 'react';
import Form from './components/Form';
import Box from './components/Box';
import './App.css';

function App() {
  const [ colorArray, setColorArray ] = useState([]);

  return (
    <div className="App">
    <h2>Box Generator</h2>
    <Form colorArray={ colorArray } setColorArray={ setColorArray}/>
    <Box colorArray={ colorArray } />
    </div>
  );
}

export default App;
