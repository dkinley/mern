import React from 'react';

const Box = (props) => {
    const { colorArray }= props;

    return (
<div>
    {
        colorArray.map((color, index) => (
            <div key={index} style={{
                display: "inline-block",
                margin: "10px",
                height: "75px",
                width: "75px",
                backgroundColor: color
                }}>
            </div>
        ))
    }
    </div>
    );
}

export default Box;