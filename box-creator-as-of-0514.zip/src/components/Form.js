import React, { useState } from 'react';

const Form = (props) => {
    const { colorArray, setColorArray } = props; 
    const [ color, setColor ] = useState("");

    const submitClick = (event) => {
        event.preventDefault();
        setColorArray( [ ...colorArray, color ] );
    setColor("");
    }

return (
    <div>
        <form onSubmit= { submitClick } style={{ margin: "20px" }}>
            <div>

                <input
                    type="text"
                    name="color"
                    value={color}
                    placeholder="Enter Your Color Choice"
                    onChange={ (e) => setColor(e.target.value)} />
            </div>
            <br/>
            <button>Add</button>
        </form>
</div>
    )
}
export default Form;

//notes from conversation with John W. 5/13 use .map, JS and object, setColor to useState

