const mongoose = require('mongoose');

const KaraokeSchema = new mongoose.Schema({
    title: {
        type: String,  //this is the validation for a song for karaoke
        required: [ true, "You must have a title for a song"],  //true - this is a required field, the 2nd part is the requirement
        minlength: [3, "Your song must be at least 3 characters long"],
    },
    artist: {
        type: String, 
        required: [ true, "You must have an artist for a song"],  //true - this is a required field, the 2nd part is the requirement
        minlength: [3, "Your artist name must be at least 3 characters long"],
    },
    albumArtUrl: {
        type: String,
        minlength: [10, "Your album art URL must be at least 10 characters long"],
    },
    videoUrl: {
        type: String,  
        minlength: [10, "Your karaoke video URL must be at least 10 characters long"],
    },
    genre: {
        type: String,
        required: [ true, "You must have a genre for a song"],
        enum: [ "Pop", "Country", "Hip Hop", "Jazz", "Rap", "Gospel", "Rock" ],
        // if it doesn't match one of these enums exactly it won'y pass validaiton
        minlength: [3, "Your song must be at least 3 characters long"],
    },

    year: {
        type: Number,
        required: [ true, "You must have a year for this karaoke to be valid"],
        min: [ 1930, "The song must be written no earlier than 1930"],
    },

    licensed: {
        type: Boolean,
        default: true,
    },
},
{ timestamps: true }); // need it! this is the options of the Schema, required

// the string to export that you use here is the name of the collection inside of the db
// the collection name will be lowercase, regardless of how you type it
// 2nd piece to export is the schema
module.exports = mongoose.model("Karaoke", KaraokeSchema);