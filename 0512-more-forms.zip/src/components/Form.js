import React, { useState } from 'react';

const Form = (props) => {
    const [ firstName, setFirstName ] = useState("This is where you see First Name!");
    const [ lastName, setLastName ] = useState("This is where you see Last Name!");
    const [ email, setEmail ] = useState("Your email shows up here");

    const formDataDivStyle = {
        textAlign: "left", 
        width: "350px", 
        margin: "auto",
    }

    const inputDataDivStyle = {
        borderRadius: "8px",
        backgroundColor: "sky",
        border: "1.5px solid darkgrey",
        padding: "2px 10px",
        margin: "6px",
    }

                return (
            <div>
            <form style={{ marginTop: "20px" }}>
                <div style={inputDataDivStyle}>
                <label htmlFor="firstName">First Name</label>
                <input 
                    type="text" 
                    name="firstName"
                    onChange={ (e) => setFirstName(e.target.value) }
                />
                </div>
                {
                    firstName.length > 0 ?
                    firstName.length < 2 ?
                        <p className="error">Yo! Your First Name must be at least 2 characters</p>
                        : null
                    : null 
                }

            <div style={inputDataDivStyle}>
            <label htmlFor="lastName">Last Name</label>
            <input 
                type="text" 
                name="lastName" 
                onChange={ (e) => setLastName(e.target.value) }
            />
            </div>
                {
                    lastName.length > 0 ?
                    lastName.length < 2 ?
                        <p className="error">Yo! Your Last Name must be at least 2 characters</p>
                        : null
                    : null 
                }

            <div style={inputDataDivStyle}>
            <label htmlFor="email">Email</label>
            <input 
                type="text" 
                name="email" 
                onChange={ (e) => setEmail(e.target.value) }
            />
            </div>
                {
                    email.length > 0 ?
                    email.length < 2 ?
                        <p className="error">Yo! Your email address must be at least 2 characters</p>
                        : null
                    : null 
                }
        </form>

        <div style={ formDataDivStyle }>
            <h3 style={{ textAlign: 'center' }}>Your Form Data</h3>
            <p>
            <label>First Name: </label>{ firstName }
            </p>
            <p>
            <label>Last Name: </label>{ lastName }
            </p>
            <p>
            <label>Email: </label>{ email }
            </p>
        </div>
        </div>
    )
    }

export default Form;