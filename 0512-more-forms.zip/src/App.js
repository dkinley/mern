import './App.css';
import Form from './components/Form';
import Pass from './components/Pass';

function App() {
  return (
    <div className="App">
      <Form />
      <Pass />
    </div>
  );
}

export default App;