import React, { useState } from 'react';
    
const UserForm = (props) => {
    const [username, setUsername] = useState("");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [hasBeenSubmitted, setHasBeenSubmitted] = useState(false);
    
    const createUser = (e) => {
        e.preventDefault();
        const newUser = { username, email, password };
        console.log("Welcome", newUser);
        setHasBeenSubmitted( true );
    };
    
    const formMessage = () => {
        if( hasBeenSubmitted ) {
	    return "Thank you for submitting the form!";
	} else {
	    return "Welcome, please submit the form";
	}
    };
    
    return (
        <div>
            <form onsubmit={ createUser }>
                <h3>{ formMessage() }</h3>
                    <div>
                        <label>Username: </label> 
                        <input type="text" onChange={ (e) => setUsername(e.target.value) } />
                    </div>
                    {
                        username.length > 0 ?
                          username.length < 2 ?
                            <p className="error">Username must be at least 2 characters</p>
                            : null
                          : null 
                      }
                    <div>
                        <label>Email Address: </label> 
                        <input type="text" onChange={ (e) => setEmail(e.target.value) } />
                    </div>
                    {
                        email.length > 0 ?
                          email.length < 2 ?
                            <p className="error">Email address must be at least 2 characters</p>
                            : null
                          : null 
                      }
                    <div>
                        <label>Password: </label>
                        <input type="text" onChange={ (e) => setPassword(e.target.value) } />
                    </div>
                    {
                        password.length > 0 ?
                          password.length < 2 ?
                            <p className="error">Password must be at least 2 characters</p>
                            : null
                          : null 
                      }
                <input type="submit" value="Create User"/>
            </form>
        </div>
    )
};
    
export default UserForm;