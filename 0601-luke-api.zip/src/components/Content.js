import React, {useState} from 'react';

const Content = (props) => {
    [content, setContent] = useState({});

    // submitHandler(() => {
    //     axios.get("https://swapi.dev/api/:content/:id")
    //     .then((response) => {
    //         console.log(response);
    //         (response.data.results);
    // })
    //     .catch((error) => {
    //     console.log("API call error, check Content component");
    // });


    return(
        <div>
        These are the People
        </div>

    )
}

export default People;