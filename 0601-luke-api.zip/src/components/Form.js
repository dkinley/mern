import React, {useState} from 'react';
import axios from "axios";
import { navigate } from "@reach/router";

    const Form = (props) => {
        const [ content, setContent ] = useState("");
        const [ contentID, setContentID ] = useState();
        const [ returned, setReturned ] = useState({});


        const submitHandler = (e) => {
            e.preventDefault();
            axios.get(`https://swapi.dev/api/${content}/${contentID}`)
            .then((response) => {
                console.log(response.data);
                setReturned(response.data);
        })
            .catch((error) => {
            console.log("API call error, check Content component");
        });
        }

        return (
            <div>
                <p>Luke APIwalker</p>
                <form onSubmit={submitHandler}>
                    <select onChange={(e)=> setContent(e.target.value)}>
                        <option>people</option>
                        <option>planets</option>
                    </select>
                    <input type="number" onChange={(e)=> setContentID(e.target.value)}/>
                    <button type="submit">Submit</button>
                </form>
                <returnedText>
                <p>
                Name : {returned.name}
                <br />
                Rotation / Height : {returned.rotation_period}
                {returned.height}
                <br />
                {returned.rotation_period}
                {returned.height}
                </p>
                </returnedText>

            </div>
        )
    }


    export default Form;