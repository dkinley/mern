import React from 'react';
import './App.css';
import Form from './components/Form';
import { Router, Link } from '@reach/router';

function App() {

  return (

    <div className="App">
    <br />
    
    <Router>
    <Form path="/" />
    </Router>
    </div>
  );
}

export default App;
