import React from 'react';
import './App.css';
import ListAll from './components/ListAll';
import New from './components/New';
import Edit from './components/Edit';
import Details from './components/Details';
import Header from './components/Header'; // anything exported as default does not require {}
import { Router } from '@reach/router'; // since router is not exported as default {} are required


function App() {
  return (
    <div className="App">
      <Header />

      <Router>
        <ListAll path="/karaoke" />
        <New path="/karaoke/new" />
        <Edit path="/karaoke/:id/edit" />
        <Details path="/karaoke/:id"/>
      </Router>
    </div>
  );
}

export default App;
