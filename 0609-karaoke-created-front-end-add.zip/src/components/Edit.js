import React, { useEffect, useState } from 'react';
import { Link, navigate } from '@reach/router';
import axios from 'axios';

const Edit = (props) => {
    return (
        <div>
            <h1>Edit component</h1>
        </div>
    )
};

export default Edit;