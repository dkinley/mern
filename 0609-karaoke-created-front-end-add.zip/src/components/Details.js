import React, { useEffect, useState } from 'react';
import { Link, navigate } from '@reach/router';
import axios from 'axios';

const Details = (props) => {
    return (
        <div>
            <h1>Details component</h1>
        </div>
    )
};

export default Details;