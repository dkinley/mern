import React, { useState } from 'react';

function App() {
  return (
    <Navbar>
      <NavItem icon= "😆 "/>
      <NavItem icon= "🤓"/>
      <NavItem icon= "😜" />

      <NavItem icon= "👇🏼" />

      <DropdownMenu />

    </Navbar>
  );
}

function DropdownMenu() {

  function DropdownItems(props) {
    return (
      <a href="#" className="menu-item">
      
      </a>
    );
  }

  return (
    <div className="dropdown">
    
    </div>
  );

}

function Navbar(props) {

  return (
    <nav className ="navbar">
      <ul className="navbar-nav"> { props.children }</ul>
    </nav>
  );
}

function NavItem(props) {

  const [open, setOpen] = useState(false);
  //open is boolean, for if dropdown is open

  return (
    <li className="nav-item">
      <a href="#" className="icon-button" onClick={() => setOpen(!open)}>
        {props.icon}
      </a>

      {open && props.children}
    </li>
  );
}


export default App;
