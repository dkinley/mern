//make create move.controller.js now
//then do below, this will include all routes, takes in app server to look
// each of the routes, with verb 'get'


const MovieController = require('../controllers/movie.controllers');

module.exports = function(app) {
    // '/api/' means it is a backend route, getAll should autopopulate from options if setup correctly
    app.get( '/api/movies', MovieController.getAll)
    app.post( '/api/movies', MovieController.create)
    // this was added after new 'create' was added in controller create: (req, res)
}

// now go server.js and add in routes to routes section of that file