const express = require('express');
const app = express();
const port = 8000;

//configure app with functionality
//turns on ability to use json
app.use(express.json());
//options object, set to extended: true allows us to handle complex request and responses
app.use(express.urlencoded({ extended: true }));

// below two items are needed to use this entire backend

// 1) access to data, go set up mongoose.config.js, this is a file ref so not to clutter server.js
require ('./config/mongoose.config');

// 2) add in routes, controller and model; start with the Model as this is the unique part of backend server
// now create movie.model.js 
// after that add move.routes.js
require('./routes/movie.routes')(app);

app.listen(port, () => console.log("Successfully connected on port " + port));
