// this file allows conenction to the database
const mongoose = require('mongoose');
//name a database
const db_name = "movie-list";

//this is the connection, this requires two different parameters.
//note this provides a Promise, so need a .then and .catch
mongoose.connect("mongodb://localhost/" + db_name, {
    // these are to handle the exceptions
    useNewUrlParser: true,
    useUnifiedTopology: true
})
    .then(() => console.log("Successfully connected to DB: " + db_name))
    //just showing the error, if there is one
    .catch((err) => console.log(err));

//note that all of this code is referenced in the ./config/mongoose.config
//path referenced in the server.js
