// has to take mongoose connection ands use mongoose to create a schema
const mongoose = require('mongoose');

// two parts of the schema, 1) definition and 2) options like time stamps
const MovieSchema = new mongoose.Schema({
    // after export setup below, start adding schema variables
    title: { 
        type: String,
        required: [ true, "Title is required" ],
        minlength : [ 3, "Your title must be at least 3 characters long" ],
        // another idea, no duplicates no same release date AND title
    },

    releaseDate: //cannot be in the future 
    {
        type: Date,
        min: [ '1930-01-01', "Minimum date for a movie is 1930" ],
        max: [ new Date() , "You cannot enter a release date that happens in the future" ],
    },
    rating: { 
        type: String,
        required: [ true, "Rating is required" ],
        minlength : [ 3, "Please enter a valid rating" ],
        maxlength : [ 7, "Rating cannot be more than 7 characters long"],
    },
    // allow only certain strings
    genre: { 
        type: String,
        required: [ true, "A genre is required" ],
        // enum is a validator that takes in an array, with valid values, then add
        enum: [ 'Comedy', 'Action', 'Horror', 'Drama', 'Romance', 'Kung Fu', 'Science Fiction', 'Foreign'], 
    }, //only allow certain strings
        
    watchLength: //min and max number of minutes
    { 
        type: Number,
        required: [ true, "Title is required" ],
        minlength : [ 80, "To be a movie you must be at least 80 min long" ],
        max: [200, "You need to be able to stay awake for it to be valid, not too long please"],
    },
    actors: //it's possible to make this into a String Array
    { 
        type: String,
        required: [ true, "Actor or Actors are required" ],
        minlength : [ 3, "Your movie must have at least one actor" ],
    },
    boxOffice: { // amount of $ it has made at the box office
        type: Number,
    },
    coverArtUrl: {
        type: String,
        required: [ true, "Your cover art is required" ],
        minlength : [ 15, "Your art url must be at least 15 characters" ],   
    },
    imdbLink: {
        type: String,  
    }, 
}, { timestamps: true })

//exporting individual variables can be combined into one statement
//the below will handle exporting model, the model function takes in Name, but
//on backend the db makes it lower case and plural. 
module.exports = mongoose.model("Movie", MovieSchema); 

//note, backend is where the data validation is ultimate responsibility
