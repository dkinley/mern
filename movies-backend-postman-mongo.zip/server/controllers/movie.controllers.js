//this does all the work. Takes request, using mongoose and the model
//need to import the model, note that we have to go up one level ".."
const Movie = require('../models/movie.model');

//need to export to be able to use them, export out whatever we give it
//if we use an object, we can give it key:value pairs which will be functions
module.exports = {
//when dealing with an api, you always get a req and a res. These two are objects
getAll: (req, res) => {
    Movie.find({})
        .then((allMovies) => {
            console.log("in all movies");
            console.log(allMovies);
            //below we are asking for the response to come back in JSON object
            res.json(allMovies);
        })
        .catch((err) => {
            console.log("error found in getAll");
            //don't forget the below, this is sending the actual response
            res.json(err);
            //now work on movie.routes.js
        })
    },
    create: (req, res) => {
        console.log(req.body);
        // .create is in mongoose, returns Promise
        Movie.create(req.body)
        .then((newMovie) => {
            console.log("in create");
            console.log(newMovie);
            res.json(newMovie);
        })
        .catch((err) => {
            console.log("error found in create");
            res.json(err);
        })
    }
}
