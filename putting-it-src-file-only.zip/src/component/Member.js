import React, { useState } from 'react';

const Member = (props) => {
    const [ age, setAge ] = useState(props.age); // delcaring a state, setAge changes age, set it = to a useState(props.age)

    const handleClick = () => {  // declaring a handler function that will change the age state, this is called onClick below
        setAge(age + 1);
    }

    const memberStyle = {  // css in-line styling
        display: "inline-block",
        height: "10px",
        width: "300px",
        margin: "10px",

   };

    return(
        <div>
        <h2 className="member-header">{ props.memberData }</h2>
        <div style={ memberStyle }>Age : { age }</div>
        <div style={ memberStyle }>Hair Color : { props.hairColor }</div>
        <br></br>
        <button onClick={ handleClick }>Age Adder</button>
        </div>
    )
}

export default Member;
