import React from 'react';

const Footer = () => {
    return (
        <img className="footer-img" src=' ./blue-footer.png' alt="wave to it"/>
    )
}

export default Footer;