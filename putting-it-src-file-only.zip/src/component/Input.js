import React from 'react';

const Input = () => {
    return (
        <div>
            <form>
                <label style= { { display: "block", marginBottom:"10px", margin: "auto" } }>Include a Friend</label>
                <input style= { { display: "block", marginBottom:"10px", margin: "auto" } } type="text" name="newPerson" />
                <button style= { { display: "block", marginBottom:"10px", margin: "auto" } }>Add an Amigo!</button>
            </form>
        </div>
    )
}

export default Input;