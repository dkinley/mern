import React from 'react';
import AllPoke from './components/AllPoke';
import './App.css';

function App() {
  return (
    <div className="App">
      <AllPoke />
    </div>
  );
}

export default App;
