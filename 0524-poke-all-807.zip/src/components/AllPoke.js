import React, { useState, useEffect } from 'react';

const AllPoke = (props) => {
    const [poke, setPoke] = useState({});

    useEffect(() => {
        fetch("https://pokeapi.co/api/v2/pokemon?limit=807")
            .then(response => response.json())
            .then(response => setPoke(response.results))
            .catch((err) => {
                console.log(err);
            })
    }, []);
    
    return (
        <div>
        <p>Your Access to All 807 of the Poke's</p>
            {poke.length > 0 && poke.map((poke, index)=>{
                return (<ul key={index}>{index + 1} {poke.name}</ul>)
        })}
        </div>
    );
}

export default AllPoke;