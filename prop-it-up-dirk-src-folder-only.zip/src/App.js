import './App.css';
import Member from './component/Member';

function App() {
  return (
    <div className="App">
          <div className="main-div">
          <Member memberData= { "Doe, Jane" } age={ "45" } hairColor={ "Black" } />
          <Member memberData= { "Smith, John" } age={ "88" } hairColor={ "Brown" } />
          <Member memberData= { "Fillmore, Millard" } age={ "50" } hairColor={ "Brown" } />
          <Member memberData= { "Smith, Maria" } age={ "62" } hairColor={ "Brown" } />
          </div>
    </div>
  );
}

export default App;
