import React from 'react';

const Member = (props) => {
    const memberStyle = {
        display: "inline-block",
        height: "10px",
        width: "300px",
        margin: "10px",
   };

    return (
        <div>
            <h2 className="member-header">{ props.memberData }</h2>
            <div style={ memberStyle }>Age : { props.age }</div>
            <div style={ memberStyle }>Hair Color : { props.hairColor }</div>
        </div>
    )
}

export default Member;