import React, {useState} from 'react';

const Paths = (props) => {
console.log(props);
    if (!props.letters) {
    return (
        <div>
        <h2>Welcome!</h2>
        </div>
    )
} else {
    if (isNaN(props.letters)) {
        return (
            <div>
            <h1 
                style={
                    props.font
                        ? { color: props.font, backgroundColor: props.backgroundColor }
                        : null
                    } >
            </h1>
            The word is: { props.letters }
            </div>
        );
} else {
    return (
        <div>
        The number is { props.letters }
        </div>
    )
}

}

}
export default Paths;