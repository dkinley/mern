import './App.css';
import React from 'react';
import Paths from './components/Paths';
import { Router } from '@reach/router';

function App() {
  return (
    <div className="App">
    Welcome to The Super Simple React App!
    <br />
    <hr />
    <Router>
    <Paths path="/:letters" />
    <Paths path="/:letters/:font/:backgroundColor" />
    </Router>
    </div>
  );
}

export default App;
