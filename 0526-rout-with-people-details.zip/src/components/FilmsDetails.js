import React, {useState, useEffect} from 'react';
import axios from 'axios';
import People from './People';

const FilmDetails = (props) => {
    const [ film, setFilm ] = useState({});
    const [ getCharacter, setCharacter ] = useState(props.person);
    
    useEffect(() => {
        axios.get("https://swapi.dev/api/films/" + props.episode_id + "/")
            .then((response) => {
                console.log("I am now over here!")
                console.log(response);
                setFilm(response.data);
            })
            .catch((error) => {
                console.log(error);
            })
        }, []);

        return (
            <div>
                <p>Title : { film.title }</p>
                <p>Episode : { film.episode_id }</p>
                <p>Release Date : { film.release_date }</p>
                <p>Director : { film.director }</p>
                <p>Producer : { film.producer }</p>
                <p>Opening : { film.opening_crawl }</p>
                <p>Characters : </p> { film.characters? film.characters.map (( characterURL ) => 
                        // People characterURL is what it is called in the People component
                        // { characterURL } is the link to the API via mapping the character array, two lines above
                        // terniary operator was needed as the API call is asynchronous
                    <People characterURL = { characterURL }/>
                    ) : "" }
            </div>
        )
}

export default FilmDetails;