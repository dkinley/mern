import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link } from '@reach/router';

const Starships = (props) => {
    const [ starships, setStarships ] = useState([]);

    // const getStarships = () => {
        // run automatically 1 time when the component loads
    useEffect(() => {

        axios.get("https://swapi.dev/api/starships")
        .then((response) => {
            console.log(response);
            setStarships(response.data.results);
            // response.json()
            //   .then((jsonResponse) => {
            //     setStarships(jsonResponse.results);
            //   })
            //   .catch((jsonError) => {
            //     console.log(jsonError);
            //   });
        })
        .catch((error) => {
            console.log(error);
        });
    // }
    }, []);

    const getStarshipIdFromUrl = (url) => {
        const urlParts = url.split("/");
        console.log(urlParts);
        return urlParts[ urlParts.length - 2 ];
    }

    return (
        <div>
        <p>This is the starships component</p>
        {/* <button onClick={ (e) => getStarships() }>Get Starships</button> */}
        {
            starships.map((ship, index) => (
            <div key={index} >
                index: {index}
                <Link to={ "/starships/" + getStarshipIdFromUrl(ship.url) } >
                <h4>{ship.name}</h4>
                </Link>
                <p>Number of Passengers: {ship.passengers}</p>
            </div>
            ))
        }
        </div>
    )
}

export default Starships;
