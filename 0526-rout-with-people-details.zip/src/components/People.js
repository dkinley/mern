import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link } from '@reach/router';

const People = (props) => {
    const [ people, setPeople ] = useState ({});

    useEffect(() => {

        axios.get(props.characterURL)
        .then((response) => {
            console.log(response);
            setPeople(response.data);
    })
    .catch((error) => {
        console.log(error);
    })
}, []);

    return (
        <div>
        <hr/>
        {people.name}
        <br/>
        {people.birth_year}
        </div>
    )
}

export default People;

