import './App.css';
import React from 'react';
import { Router, Link } from '@reach/router';
import Starships from './components/Starships';
import Films from './components/Films';
import FilmsDetails from './components/FilmsDetails';

function App() {
  return (
    <div className="App">
    <Link to="/starships">Starship List</Link>
    <br />
    <Link to="/films">Film List</Link>
    <hr />
    <Router>
      <Starships path="/starships" />
      <Films path="/films" />
      <FilmsDetails path="/films/:episode_id" />
      <FilmsDetails path="/films/:episode_id/people/" />
    </Router>
    <hr />  
    </div>
  );
}

export default App;
