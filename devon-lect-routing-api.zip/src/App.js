import './App.css';
import axios from 'axios';
import React, {useState, useEffect} from 'react';
import Starships from './components/Starships';
import StarshipDetails from './components/StarshipDetails';
import { Router } from '@reach/router';

function App() {

  return(
    <div className="App">
    <h2>StarWars App!</h2>
    <Router>
    <Starships path= '/' />
    <StarshipDetails path= '/:starshipID' />
    </Router>
    </div>
  )
}

export default App;
