import axios from 'axios';
import React, {useState, useEffect} from 'react';
import Starships from './Starships';

const StarshipDetails = (props) => {

    const [starship, setStarship] = useState({});

    useEffect(() => {

        axios.get('https://swapi.dev/api/starships/' + props.starshipID)
            .then((res) => {
                setStarship(res.data);
            })

        }, []);

    return (
        <div>
            <h1>{ starship.name }</h1>
            <p><strong>Model : </strong> { starship.model}</p>
            <p><strong>Manufacturer : </strong> { starship.manufacturer}</p>
            <p><strong>Class : </strong> { starship.starship_class}</p>
            <p><strong>Crew : </strong> { starship.crew}</p>
            <p><strong>Passengers : </strong> { starship.passengers}</p>
            <p><strong>Cargo Capacity : </strong> { starship.cargo_capacity}</p>
            <p><strong>Consumables : </strong> { starship.consumables}</p>
        </div>
    )
}

export default StarshipDetails;