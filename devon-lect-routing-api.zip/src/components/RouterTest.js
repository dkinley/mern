import React from 'react';
import { Router, Link } from '@reach/router';

const MainPage = () => {
    return (
        <h1>This is the main the page!</h1>
    )
}

const OtherPage = () => {
    return (
        <div>
        <h1>This is the other page!</h1>
        <Link to= "/" >Take me home</Link>
        </div>
    )
}

const DetailsPage = (props) => {
    return (
        <h1>Details about {props.name}</h1>
    )
}

const RouterTest = () => {
    return (
        <div>
            <Router>
                <MainPage path= "/" />
                <OtherPage path="/other"/>
                <DetailsPage path="/users/:name"/>
            </Router>
        </div>
    )
}

export default RouterTest;