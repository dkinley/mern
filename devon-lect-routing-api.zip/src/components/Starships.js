import axios from 'axios';
import { Link } from '@reach/router';
import React, {useState, useEffect} from 'react';

const Starships = () => {

    const [ starshipArray, setStarshipArray ] = useState([]);
    const [ starshipUrl, setStarshipUrl ] = useState('https://swapi.dev/api/starships/');
    const [ nextUrl, setNextUrl ] = useState("");
    const [ prevUrl, setPrevUrl ] = useState("");

    function getShipID(url) {
        const splitItems = url.split("/");
        return splitItems[ splitItems.length -2];
    }
    
        useEffect(() => {

        axios.get(starshipUrl)
            .then((res) => {
            console.log(res.data, "from axios");
            setStarshipArray(res.data.results);
            setNextUrl(res.data.next);
            setPrevUrl(res.data.previous);
            })
    
        }, [starshipUrl]);
    
        return (
            <div>
            {
            nextUrl?
            <button onClick={ () => setStarshipUrl(nextUrl)}>Next Starships</button>
            : null    
            }
            
            {
            prevUrl?
            <button onClick={ () => setStarshipUrl(prevUrl)}>Previous Starships</button>
            : null
            }
    
            <table className="table table-striped">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Class</th>
                    </tr>
                </thead>
                <tbody>
            {
            starshipArray.map((ship, index) => (
                <tr key={index}>
                    <td><Link to={`/${ getShipID(ship.url)}`}>{ ship.name }</Link></td>
                    <td>{ship.starship_class}</td>
                </tr>
            ))
            }
            </tbody>
            </table>
        </div>
    );

}


export default Starships;