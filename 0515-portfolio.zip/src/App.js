import React from 'react';
import './App.css';
import Navbar from './components/Navbar'
import MainContent from './components/MainContent'
import Projects from './views/Projects'

function App() {
  return (
    <div className="App">
    <h1>Welcome to My Portfolio</h1>
    <Navbar />  {/*Header with Navbar*/}
    <MainContent /> {/*Main Content*/}
    <Projects />{/*Projects*/}
    {/*Footer*/}
    </div>
  );
}

export default App;
