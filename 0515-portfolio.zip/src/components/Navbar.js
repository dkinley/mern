import React from 'react'; // to do, look into npm package @reach/router; also look into snipets

const Navbar = () => {
    return (
        <div>
        <button>Home</button>
        <button>Projects</button>
        <button>About Me</button>
        <button>Contact Me</button>
        </div>
    )
}

export default Navbar;