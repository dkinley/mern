import React from 'react';

const MainContent = () => {

return (
    <div>
        <h4>This is about me!</h4>
        <p>Yuccie kitsch ipsum nulla ad VHS id est, cold-pressed affogato butcher 
        schlitz in. Eu pour-over quinoa plaid hot chicken small batch, venmo af 
        food truck raw denim shoreditch. Next level freegan +1 cray laborum, bicycle 
        rights sed master cleanse enim yr hot chicken 3 wolf moon affogato brunch. 
        Iceland marfa beard fixie fugiat iPhone la croix squid authentic four 
        dollar toast hell of lorem. Cornhole nostrud aliqua occaecat succulents. 
        Aesthetic succulents DIY enamel pin, cillum selvage kombucha deep v 
        mixtape venmo ex vice street art cred. Fingerstache labore lumbersexual 
        chicharrones, eiusmod affogato typewriter direct trade 90's drinking vinegar 
        irure commodo mollit.
        </p>
    </div>
)
}
export default MainContent;