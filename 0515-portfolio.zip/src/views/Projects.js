import React from 'react';
import Project from '../components/Project';

const Projects = () => {

return (
    <div>
    <h4>This is the Projects Component</h4>
    <Project title= { "Window Wizard"} description= { "College Student Window Washing" }/>
    <Project title= { "Puppy Rescue"} description= { "Find a Foster Family for Rescue Puppies" }/>
    <Project title= { "Restroom Rater"} description= { "Rating for Public Restrooms" }/>
    </div>
)
}

export default Projects;