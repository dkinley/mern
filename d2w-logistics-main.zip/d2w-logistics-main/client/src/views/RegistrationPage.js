import React from 'react';
import RegisterUser from '../components/RegisterUser';

const RegistrationPage = (props) => {
	return(
		<div>
			<RegisterUser />
		</div>
	)
}

export default RegistrationPage;