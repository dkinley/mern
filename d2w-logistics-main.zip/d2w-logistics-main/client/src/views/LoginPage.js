import React from 'react';
import Login from '../components/Login';

const LoginPage = (props) => {
	return(
		<div>
			<Login />
		</div>
	)
}

export default LoginPage;