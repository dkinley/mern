import React from 'react';
import './App.css';
import {
  BrowserRouter as Router,
  Route,
} from "react-router-dom";

import PageOne from './components/PageOne';
import PageTwo from './components/PageTwo';

function App() {
  return (
    <Router>
    <div className="App">
      <Route exact path="/route-one"><PageOne/></Route>
      <Route exact path="/route-two"><PageTwo/></Route>
    </div>
    </Router>
  );
}

export default App;


