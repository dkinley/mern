import React from 'react';
import {
    BrowserRouter as Router,
    Link
  } from "react-router-dom";

const PageTwo = (props) => {
    return(
        <div>
        <p>Welcome to Page Two</p>
        <br />
        <Link to="/route-one">Go to Page One</Link>
        </div>
    )
}
export default PageTwo;