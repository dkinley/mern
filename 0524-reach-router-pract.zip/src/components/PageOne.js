import React from 'react';
import {
    BrowserRouter as Router,
    Link
  } from "react-router-dom";

const PageOne = props => {
    
    return(
        <div>
        <p>Welcome to Page One</p>
        <br />
        <Link to="/route-two">Go to Page Two</Link>
        </div>
    )
}
export default PageOne;