import React from 'react';

const Tabs = (props) => {
    const { allTabs, currentTabIndex, setCurrentTabIndex} = props;

    const setSelectedTab = (index) => {
        setCurrentTabIndex(index);   
        }

    // const tabAccent = (index === currentTabIndex) ?
    // "selectedTab" : "nonSelected"; 
    
        const tabAccent = (index) => {
           return (
            index === currentTabIndex ? "selectedTab" : "nonSelected"
           ) 

        }

    return (
        <div className= {"tabLook"}>
        {

            allTabs.map((item, index) => ( 
                //<div className={index === currentTabIndex ? "selectedTab" : "nonSelected"} onClick={(e) => setSelectedTab (index) }>
                <div className={tabAccent(index)} onClick={(e) => setSelectedTab (index) }>
                { item.name }
                </div>
            ))
        }
        </div>
    )
}

export default Tabs;