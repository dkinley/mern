import React, { useState } from 'react';
import Tabs from './components/Tabs';
import Results from './components/Results';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';

function App() {
  const tabsArray = [
    {name: "Tab Uno", content: "Ready"},
    {name: "Tab Dos", content: "Set"},
    {name: "Tab Tres", content: "Go!"},
  ];

  // the below is needed to group Array items above into a setter 'setAllTabs'
  // which will be used to build tabs display of all tabs at once

  const [ allTabs, setAllTabs] = useState(tabsArray);

  // tab index provides cataloging of array members
  const [ currentTabIndex, setCurrentTabIndex ] = useState(0);

  return (
    <div className="App">
    <Tabs 
    /* passing down the array tabs, their index and index setter via props */
      allTabs ={ allTabs }
      currentTabIndex= { currentTabIndex }
      setCurrentTabIndex={ setCurrentTabIndex }
    />
    <Results 
      allTabs={ allTabs } currentTabIndex={ currentTabIndex } 
    />
    </div>
  );
}

export default App;
