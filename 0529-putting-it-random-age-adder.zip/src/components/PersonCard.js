import React, { useState } from "react";

const PersonCard = (props) => {
    const [birthdayAge, setBirthdayAge] = useState(props.age);
        const {firstName, lastName, hair} = props;

    return (
        <div className = "container">
        <h2>
        {lastName}, {firstName}
        </h2>
        <h4>
        <p>Age: {birthdayAge}</p>
        </h4>
        <br />
        <button onClick={() => setBirthdayAge( birthdayAge + Math.random())}>
        Adds Random Years for {firstName} {lastName}
        </button>
        </div>
    );
}

export default PersonCard;