import React from 'react';
import PersonCard from './components/PersonCard';
import './App.css';

function App() {
  return (
    <div className="App">
    
    <PersonCard
    lastName={"Coinson"}
    firstName={"Jerald"}
    age={53}
    hair={"dark brown"}
  />
  <PersonCard
    lastName={"Crowe"}
    firstName={"Russell T."}
    age={31}
    hair={"none"}
  />
    </div>
  );
}

export default App;
